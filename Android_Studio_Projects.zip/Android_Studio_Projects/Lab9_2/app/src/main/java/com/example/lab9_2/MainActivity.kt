package com.example.lab9_2

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

/** Lab 9.3：以 Coroutine 模擬五秒檢測，讓使用者仍可正常使用主執行緒。 */
class MainActivity : AppCompatActivity() {
    private var checkJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        val btnCalculate = findViewById<Button>(R.id.btnCalculate)
        val edHeight = findViewById<EditText>(R.id.edHeight)
        val edWeight = findViewById<EditText>(R.id.edWeight)
        val edAge = findViewById<EditText>(R.id.edAge)
        val btnBoy = findViewById<RadioButton>(R.id.btnBoy)
        val progressBar = findViewById<ProgressBar>(R.id.progressBar)
        val tvProgress = findViewById<TextView>(R.id.tvProgress)
        val llProgress = findViewById<LinearLayout>(R.id.llProgress)
        val tvWeightResult = findViewById<TextView>(R.id.tvWeightResult)
        val tvFatResult = findViewById<TextView>(R.id.tvFatResult)
        val tvBmiResult = findViewById<TextView>(R.id.tvBmiResult)

        btnCalculate.setOnClickListener {
            // 在啟動 Coroutine 前先讀取與驗證輸入，避免處理期間被使用者改寫。
            val height = edHeight.text.toString().trim().toDoubleOrNull()
            val weight = edWeight.text.toString().trim().toDoubleOrNull()
            val age = edAge.text.toString().trim().toDoubleOrNull()
            if (height == null || !height.isFinite() || height <= 0.0) {
                showToast("請輸入正確的身高（公分）")
                return@setOnClickListener
            }
            if (weight == null || !weight.isFinite() || weight <= 0.0) {
                showToast("請輸入正確的體重（公斤）")
                return@setOnClickListener
            }
            if (age == null || !age.isFinite() || age <= 0.0) {
                showToast("請輸入正確的年齡")
                return@setOnClickListener
            }
            val isMale = btnBoy.isChecked
            val metrics = BodyMetrics.calculate(height, weight, age, isMale)
            tvWeightResult.text = "標準體重\n無"
            tvFatResult.text = "體脂肪\n無"
            tvBmiResult.text = "BMI\n無"
            progressBar.max = 100
            progressBar.progress = 0
            tvProgress.text = "0%"
            llProgress.visibility = View.VISIBLE
            btnCalculate.isEnabled = false

            checkJob?.cancel()
            checkJob = lifecycleScope.launch {
                try {
                    // delay(50) 是非阻塞式暫停；100 次共約五秒，逐步更新進度。
                    repeat(100) { index ->
                        delay(50)
                        val value = index + 1
                        progressBar.progress = value
                        tvProgress.text = "$value%"
                    }
                    tvWeightResult.text = "標準體重\n${fmt(metrics.standardWeight)} kg"
                    tvFatResult.text = "體脂肪估計\n${fmt(metrics.estimatedBodyFat)} %"
                    tvBmiResult.text = "BMI\n${fmt(metrics.bmi)}"
                } finally {
                    // 成功、取消或異常都恢復按鈕與遮罩。
                    llProgress.visibility = View.GONE
                    btnCalculate.isEnabled = true
                }
            }
        }
    }

    private fun fmt(value: Double): String = String.format(Locale.TAIWAN, "%.2f", value)

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
