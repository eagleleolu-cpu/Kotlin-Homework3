package com.example.lab9_2

import kotlin.math.pow

/** 純 Kotlin 計算模組：不依賴 Activity，方便獨立進行數值測試。 */
object BodyMetrics {
    data class Result(val standardWeight: Double, val estimatedBodyFat: Double, val bmi: Double)

    fun calculate(heightCm: Double, weightKg: Double, age: Double, isMale: Boolean): Result {
        // 避免除以零或不合理的負值輸入，讓錯誤能被呼叫端處理。
        require(heightCm > 0.0 && heightCm.isFinite()) { "身高必須大於零" }
        require(weightKg > 0.0 && weightKg.isFinite()) { "體重必須大於零" }
        require(age > 0.0 && age.isFinite()) { "年齡必須大於零" }
        val bmi = weightKg / (heightCm / 100.0).pow(2)
        // 以下兩式採用原始教材的計算方式；體脂率僅是公式估計值。
        val standardWeight = if (isMale) (heightCm - 80.0) * 0.7 else (heightCm - 70.0) * 0.6
        val bodyFat = 1.39 * bmi + 0.16 * age - (if (isMale) 19.34 else 9.0)
        return Result(standardWeight, bodyFat, bmi)
    }
}
