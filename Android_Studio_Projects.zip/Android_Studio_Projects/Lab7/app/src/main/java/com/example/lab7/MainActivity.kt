package com.example.lab7

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.GridView
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/** 第七章：示範 Spinner、GridView、ListView，並完成可累加的水果購物清單。 */
class MainActivity : AppCompatActivity() {
    // 集中保存購物清單，避免畫面變動後總價與數量不同步。
    private val cart = linkedMapOf<String, Int>()
    private val fruits = mutableListOf<Item>()
    private lateinit var tvCart: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // 將系統狀態列與導覽列保留的區域加入畫面內距。
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left + 16, bars.top + 16, bars.right + 16, bars.bottom + 16)
            insets
        }

        val spinner = findViewById<Spinner>(R.id.spinner)
        val listView = findViewById<ListView>(R.id.listView)
        val gridView = findViewById<GridView>(R.id.gridView)
        val btnClear = findViewById<Button>(R.id.btnClearCart)
        tvCart = findViewById(R.id.tvCart)

        // 從教材原有的圖片清單載入十二種水果，並使用固定單價以利測試。
        val names = listOf("蘋果", "酪梨", "香蕉", "櫻桃", "椰子", "葡萄",
            "檸檬", "柳橙", "水蜜桃", "鳳梨", "草莓", "番茄")
        val photos = resources.obtainTypedArray(R.array.image_list)
        try {
            repeat(photos.length()) { index ->
                fruits.add(Item(photos.getResourceId(index, 0),
                    names.getOrElse(index) { "水果${index + 1}" }, 20 + 5 * index))
            }
        } finally {
            // TypedArray 需要主動釋放，以免占用資源。
            photos.recycle()
        }

        // 使用 Spinner 決定每次加入購物清單的數量（1～10 個）。
        val quantities = (1..10).map { "${it} 個" }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, quantities)
        gridView.numColumns = 3
        gridView.adapter = MyAdapter(this, fruits, R.layout.adapter_vertical)
        listView.adapter = MyAdapter(this, fruits, R.layout.adapter_horizontal)

        // 格狀與列表點擊皆能加入購物清單，重用相同的商業邏輯。
        gridView.setOnItemClickListener { _, _, position, _ ->
            addToCart(fruits[position], spinner.selectedItemPosition + 1)
        }
        listView.setOnItemClickListener { _, _, position, _ ->
            addToCart(fruits[position], spinner.selectedItemPosition + 1)
        }
        btnClear.setOnClickListener {
            cart.clear()
            showCart()
        }

        // 畫面旋轉後還原購物數量，避免重新建立 Activity 導致資料遺失。
        savedInstanceState?.let { state ->
            val names = state.getStringArrayList("cart_names").orEmpty()
            val amounts = state.getIntegerArrayList("cart_amounts").orEmpty()
            names.forEachIndexed { index, name -> cart[name] = amounts.getOrNull(index) ?: 0 }
        }
        showCart()
    }

    private fun addToCart(item: Item, count: Int) {
        cart[item.name] = (cart[item.name] ?: 0) + count
        showCart()
        Toast.makeText(this, "已加入 ${item.name} × $count", Toast.LENGTH_SHORT).show()
    }

    private fun showCart() {
        // 依名稱對應單價計算金額，並將明細完整顯示給使用者。
        if (cart.isEmpty()) {
            tvCart.text = "購物清單：目前沒有商品"
            return
        }
        val lines = cart.map { (name, quantity) ->
            val price = fruits.firstOrNull { it.name == name }?.price ?: 0
            "$name × $quantity = ${price * quantity} 元"
        }
        val total = cart.entries.sumOf { (name, quantity) ->
            (fruits.firstOrNull { it.name == name }?.price ?: 0) * quantity
        }
        tvCart.text = "購物清單｜總額 $total 元\n${lines.joinToString("、")}"
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putStringArrayList("cart_names", ArrayList(cart.keys))
        outState.putIntegerArrayList("cart_amounts", ArrayList(cart.values))
    }
}
