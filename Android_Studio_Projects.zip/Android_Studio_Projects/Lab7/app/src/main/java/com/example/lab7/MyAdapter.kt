package com.example.lab7

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView

/** 共用清單 Adapter：重複利用 convertView，避免每次捲動都重新建立元件。 */
class MyAdapter(context: Context, data: List<Item>, private val layout: Int) :
    ArrayAdapter<Item>(context, layout, data) {

    // ViewHolder 緩存 findViewById 結果，降低列表滾動時的查找次數。
    private data class Holder(val photo: ImageView, val message: TextView)

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view: View
        val holder: Holder
        if (convertView == null) {
            view = LayoutInflater.from(context).inflate(layout, parent, false)
            holder = Holder(view.findViewById(R.id.imgPhoto), view.findViewById(R.id.tvMsg))
            view.tag = holder
        } else {
            view = convertView
            holder = view.tag as Holder
        }
        val item = getItem(position) ?: return view
        holder.photo.setImageResource(item.photo)
        holder.message.text = if (layout == R.layout.adapter_vertical) item.name
            else "${item.name}：${item.price} 元"
        return view
    }
}
