package com.example.lab8

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** 使用 ViewHolder 複用每筆聯絡人列，並只通知真正異動的位置。 */
class MyAdapter(private val data: MutableList<Contact>) : RecyclerView.Adapter<MyAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val tvName: TextView = view.findViewById(R.id.tvName)
        private val tvPhone: TextView = view.findViewById(R.id.tvPhone)
        private val btnDelete: ImageView = view.findViewById(R.id.imgDelete)

        fun bind(item: Contact, onDelete: () -> Unit) {
            tvName.text = item.name
            tvPhone.text = item.phone
            btnDelete.setOnClickListener { onDelete() }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.adapter_row, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = data.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(data[position]) {
            // 按下刪除時重新取得當前位置，避免資料更新後引用舊的 position。
            val currentIndex = holder.bindingAdapterPosition
            if (currentIndex != RecyclerView.NO_POSITION) {
                data.removeAt(currentIndex)
                notifyItemRemoved(currentIndex)
            }
        }
    }

    fun addContact(contact: Contact) {
        data.add(contact)
        notifyItemInserted(data.lastIndex)
    }
}
