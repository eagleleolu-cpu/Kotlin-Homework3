package com.example.lab8

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** 第八章：以 RecyclerView 和 ViewHolder 完成可新增、刪除的通訊錄。 */
class MainActivity : AppCompatActivity() {
    private val contacts = ArrayList<Contact>()
    private lateinit var adapter: MyAdapter

    // Activity Result API 接收新增聯絡人畫面回傳的姓名與電話。
    private val startForResult = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val name = result.data?.getStringExtra("name")?.trim().orEmpty()
            val phone = result.data?.getStringExtra("phone")?.trim().orEmpty()
            if (name.isNotEmpty() && phone.isNotEmpty()) adapter.addContact(Contact(name, phone))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        // 將先前儲存的兩組字串還原為 Contact，讓旋轉螢幕時仍保有資料。
        val names = savedInstanceState?.getStringArrayList("contact_names").orEmpty()
        val phones = savedInstanceState?.getStringArrayList("contact_phones").orEmpty()
        names.zip(phones).forEach { (name, phone) -> contacts.add(Contact(name, phone)) }

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = MyAdapter(contacts)
        recyclerView.adapter = adapter
        findViewById<Button>(R.id.btnAdd).setOnClickListener {
            startForResult.launch(Intent(this, SecActivity::class.java))
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putStringArrayList("contact_names", ArrayList(contacts.map { it.name }))
        outState.putStringArrayList("contact_phones", ArrayList(contacts.map { it.phone }))
    }
}
