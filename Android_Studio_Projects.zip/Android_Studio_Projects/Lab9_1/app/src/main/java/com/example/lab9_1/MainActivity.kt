package com.example.lab9_1

import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Lab 9.1／9.2：使用 launch + delay 執行龜兔賽跑，不建立 Thread。 */
class MainActivity : AppCompatActivity() {
    private var rabbit = 0
    private var turtle = 0
    private var winner: String? = null
    private var raceJob: Job? = null
    private lateinit var btnStart: Button
    private lateinit var sbRabbit: SeekBar
    private lateinit var sbTurtle: SeekBar
    private lateinit var tvStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left + 16, bars.top + 16, bars.right + 16, bars.bottom + 16)
            insets
        }

        btnStart = findViewById(R.id.btnStart)
        sbRabbit = findViewById(R.id.sbRabbit)
        sbTurtle = findViewById(R.id.sbTurtle)
        tvStatus = findViewById(R.id.tvStatus)
        sbRabbit.max = 100
        sbTurtle.max = 100
        sbRabbit.isEnabled = false
        sbTurtle.isEnabled = false
        btnStart.setOnClickListener { startRace() }
    }

    private fun startRace() {
        // 每次開賽前重設兩條進度條；比賽中停用按鈕避免同時開多場。
        raceJob?.cancel()
        rabbit = 0
        turtle = 0
        winner = null
        sbRabbit.progress = 0
        sbTurtle.progress = 0
        btnStart.isEnabled = false
        tvStatus.text = "比賽進行中……"

        // lifecycleScope 會在 Activity 銷毀時自動取消工作，避免背景工作持續更新舊畫面。
        raceJob = lifecycleScope.launch {
            // coroutineScope 內兩個 launch 可交錯執行；delay 不會阻塞主執行緒。
            coroutineScope {
                launch { runRabbit() }
                launch { runTurtle() }
            }
            tvStatus.text = "比賽結果：${winner ?: "未分勝負"}勝利！"
            btnStart.isEnabled = true
        }
    }

    private suspend fun runRabbit() {
        // 兔子每次跑三格，其中約三分之二機率會多休息 300 毫秒。
        while (winner == null) {
            delay(100)
            if ((0..2).random() != 2) delay(300)
            if (winner != null) break
            rabbit = (rabbit + 3).coerceAtMost(100)
            sbRabbit.progress = rabbit
            if (rabbit >= 100) winner = "兔子"
        }
    }

    private suspend fun runTurtle() {
        // 烏龜不偷懶：每 100 毫秒前進一格。
        while (winner == null) {
            delay(100)
            if (winner != null) break
            turtle = (turtle + 1).coerceAtMost(100)
            sbTurtle.progress = turtle
            if (turtle >= 100) winner = "烏龜"
        }
    }
}
